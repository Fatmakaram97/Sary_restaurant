from django import forms
from .models import *

class AdminForm(forms.ModelForm):
    class Meta:
        model = Admin
        widgets = {'admin_password': forms.PasswordInput(),}
        fields = ['admin_name', 'admin_password']
    def clean_admin_name(self): # Validates the admin Name Field
        admin_name = self.cleaned_data.get('admin_name')
        for instance in Admin.objects.all():
            if instance.admin_name != admin_name:
                raise forms.ValidationError(admin_name + ' is not exist.')
        return admin_name


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        widgets = {'employee_password': forms.PasswordInput(),}
        fields = ['employee_number', 'employee_password']
    def clean_employee_name(self): # Validates the employee number Field
        employee_number = self.cleaned_data.get('employee_number')
        for instance in Employee.objects.all():
            if instance.employee_number == employee_number:
                raise forms.ValidationError(employee_number + ' is already added')
        return employee_number


class TableForm(forms.ModelForm):
    class Meta:
        model = Table
        fields = ['table_number_added', 'number_of_seats']
    def clean_table_number(self): # Validates the table number Field
        table_number_added = self.cleaned_data.get('table_number_added')
        for instance in Table.objects.all():
            if instance.table_number_added == table_number_added:
                raise forms.ValidationError(table_number_added + ' is already added')
        return table_number_added

