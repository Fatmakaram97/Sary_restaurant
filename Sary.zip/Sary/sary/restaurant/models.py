from django.db import models

#Create your models here.
class Admin(models.Model):
  admin_name = models.CharField(max_length=255)
  admin_password = models.IntegerField()

class Employee(models.Model):
  employee_number = models.IntegerField()
  employee_password = models.IntegerField()

class Reservation(models.Model):
  customername = models.CharField(max_length=255)
  size = models.IntegerField()
  tablenumber = models.IntegerField()


class Table(models.Model):
  table_number_added = models.IntegerField()
  number_of_seats = models.IntegerField()





