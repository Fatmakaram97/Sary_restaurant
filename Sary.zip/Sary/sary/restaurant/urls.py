from django.urls import path
from . import views

urlpatterns = [
    path('', views.welcome, name='welcome'),
    path('admin/', views.admin, name='admin'),
    path('admin/adminlog/', views.adminlog, name='adminpage'),
    path('employee/', views.employee, name='employee'),
    path('employee/employeelog/', views.employeelog, name='employeepage'),
    path('employee/employeelog/add/', views.add, name='add'),
    path('employee/employeelog/add/addrecord/', views.addrecord, name='addrecord'),
    path('employee/employeelog/delete/<int:id>', views.delete, name='delete'),
    path('index/', views.index, name='index'),
    path('admin/adminlog/newemployee/', views.addnewemp, name='addnewemployee'),
    path('admin/adminlog/newemployee/newemployee/', views.newemployee, name='newemployee'),
    path('admin/adminlog/tables/', views.table, name='tables'),
    path('admin/adminlog/tables/addtable/', views.addnewtable, name='addnewtable'),
    path('admin/adminlog/tables/addtable/addtable/', views.addtable, name='addtable'),
    path('admin/adminlog/tables/addtable/addtable/delete/<int:id>', views.deletetable, name='deletetable'),
    path('admin/adminlog/add/', views.add, name='add'),
    path('admin/adminlog/add/addrecord/', views.addrecord, name='addrecord'),
    path('admin/adminlog/delete/<int:id>', views.delete, name='delete'),
]