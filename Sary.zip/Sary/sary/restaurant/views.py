from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.template import loader
from .models import *

from django.contrib import messages

from .form import *

def welcome(request):
    template = loader.get_template('firstHTML.html')
    return HttpResponse(template.render())

def admin(request):
    form = AdminForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, "admin.html",context)


def adminlog(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = AdminForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            template = loader.get_template('adminpage.html')
            myreservation = Reservation.objects.all().values()
            context = {
                'myreservation': myreservation,
                }
            return render(request, 'adminpage.html', context)
    else:
        form = AdminForm()
        return render(request, 'admin.html', {'form': form})


def employee(request):
    template = loader.get_template('employee.html')
    return HttpResponse(template.render())

def employeelog(request):
    template = loader.get_template('employeepage.html')
    myreservation = Reservation.objects.all().values()
    context = {
        'myreservation': myreservation,
        }
    return HttpResponse(template.render(context, request))


def index(request):
    myreservation = Reservation.objects.all().values()
    template = loader.get_template('index.html')
    context = {
        'myreservation': myreservation,
        }
    return HttpResponse(template.render(context, request))

def table(request):
    mytables = Table.objects.all().values()
    template = loader.get_template('tables.html')
    context = {
        'mytables': mytables,
        }
    return HttpResponse(template.render(context, request))

def addnewtable(request):
    #template = loader.get_template('addtable.html')
    #return HttpResponse(template.render({}, request))
    form = TableForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, "addtable.html",context)


def addtable(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = TableForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            mytables = Table.objects.all().values()
            template = loader.get_template('tables.html')
            context = {
                'mytables': mytables,
                }
            return render(request, 'tables.html', context)
    else:
        form = TableForm()
        return render(request, 'addemployee.html', {'form': form})


def addnewemp(request):
    form = EmployeeForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, "addemployee.html",context)

def newemployee(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = EmployeeForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            template = loader.get_template('adminpage.html')
            myreservation = Reservation.objects.all().values()
            context = {
                'myreservation': myreservation,
                }
            return render(request, 'adminpage.html', context)
    else:
        form = EmployeeForm()
        return render(request, 'addemployee.html', {'form': form})


def add(request):
    template = loader.get_template('add.html')
    return HttpResponse(template.render({}, request))

def addrecord(request):
    customer = request.POST['customername']
    size = request.POST['size']
    tablenumber = request.POST['tablenumber']
    newreservation = Reservation(customername = customer, size = size, tablenumber = tablenumber)
    try:
        newreservation= Reservation.objects.get(tablenumber=tablenumber)
        #context= {'error':'The table number you entered has already been taken. Please try another table number.'}
        messages.error(request, 'The table number you entered has already been taken. Please try another table number.')
        return render(request, 'add.html')
    except Reservation.DoesNotExist:
       # newreservation= Reservation.objects.create_user(uservalue, password= passwordvalue1, email=emailvalue)
        newreservation.save()
    return HttpResponseRedirect(reverse('index'))

def delete(request, id):
  reservation = Reservation.objects.get(id=id)
  reservation.delete()
  return HttpResponseRedirect(reverse('index'))

def deletetable(request, id):
  table = Table.objects.get(id=id)
  table.delete()
  return HttpResponseRedirect(reverse('tables'))

#def update(request, id):
#  myreservation = Reservation.objects.get(id=id)
#  template = loader.get_template('update.html')
#  context = {
#    'myreservation': myreservation,
#  }
#  return HttpResponse(template.render(context, request))


#def updaterecord(request, id):
#    customer = request.POST['customername']
#    size = request.POST['size']
#    tablenumber = request.POST['tablenumber']
#    myreservation = Reservation.objects.get(id=id)
#    myreservation.customername = customer
#    myreservation.size = size
#    myreservation.tablenumber = tablenumber
#    myreservation.save()
#    return HttpResponseRedirect(reverse('index'))