from django.contrib import admin

# Register your models here.

from .models import *
from .form import *

class RestaurantAdmin(admin.ModelAdmin):
    list_display = ["admin_name", "admin_password"]
    form = AdminForm
    list_filter = ['admin_name']
    search_fields = ['admin_name']

class RestaurantEmployee(admin.ModelAdmin):
    list_display = ['employee_number', 'employee_password']
    form = EmployeeForm
    list_filter = ['employee_number']
    search_fields = ['employee_number']


class RestaurantTable(admin.ModelAdmin):
    list_display = ['table_number_added', 'number_of_seats']
    form = TableForm
    list_filter = ['table_number_added', 'number_of_seats']
    search_fields = ['table_number_added', 'number_of_seats']


admin.site.register(Admin, RestaurantAdmin)
admin.site.register(Employee, RestaurantEmployee)
admin.site.register(Table, RestaurantTable)
